find . -name "*.bkp" |xargs rm 
find . -name "shci.e" |xargs rm
find . -name "spatialRDM.*.txt"|xargs rm
